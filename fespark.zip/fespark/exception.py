
class FesqlException(Exception):

  def FesqlException(self, msg):
    self.msg = msg
