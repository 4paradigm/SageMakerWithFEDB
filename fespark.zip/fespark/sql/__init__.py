
# Use to be compatible with PySpark API
from ..session import FesqlSession as SparkSession
